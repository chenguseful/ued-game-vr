export class ImprovedNoise {

	constructor();
	noise( x: number, y: number, z: number ): number;

}
